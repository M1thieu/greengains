#!/usr/bin/env node

/**
 * Domain Name Availability Checker
 *
 * Usage:
 *   node check-domains.mjs                  # Check built-in name candidates
 *   node check-domains.mjs name1 name2 ...  # Check specific names
 *   node check-domains.mjs --file names.txt # Check names from file (one per line)
 *   node check-domains.mjs --gen            # Generate + check random 1-syllable candidates
 *   node check-domains.mjs --gen 50         # Generate + check 50 random candidates
 */

import net from 'net';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ── Config ──────────────────────────────────────────────────────────────
const DELAY_MS = 1200;

// TLD config - change these to check different extensions
const TLD = process.env.TLD || '.io';
const WHOIS_SERVERS = {
  '.com': 'whois.verisign-grs.com',
  '.io': 'whois.nic.io',
  '.app': 'whois.nic.google',
  '.co': 'whois.nic.co',
  '.dev': 'whois.nic.google',
};
const WHOIS_SERVER = WHOIS_SERVERS[TLD] || 'whois.verisign-grs.com';
const WHOIS_PORT = 43;
const TIMEOUT = 8000;

// ── 1-Syllable Curated Name Candidates ──────────────────────────────────
const CURATED_NAMES = [
  // Nature / Environment (hidden green meaning)
  'lux', 'sol', 'flux', 'vox', 'zen',
  'arc', 'orb', 'crux', 'glow', 'dew',
  'bloom', 'spore', 'fern', 'moss', 'root',
  'grove', 'reef', 'peak', 'drift', 'haze',

  // Tech / Data / Sensors
  'pulse', 'node', 'mesh', 'grid', 'byte',
  'volt', 'beam', 'core', 'nest', 'link',
  'ping', 'sync', 'scan', 'trace', 'scope',

  // Abstract / Professional
  'gist', 'verve', 'vim', 'pith', 'glyph',
  'nexus', 'prism', 'shift', 'spark', 'forge',
  'craft', 'helm', 'base', 'sage', 'brine',

  // Movement / Growth
  'surge', 'stride', 'leap', 'swift', 'rise',
  'thrive', 'sprint', 'thrust', 'climb', 'sprout',

  // Sense / Perception (sensor data)
  'sense', 'sight', 'touch', 'feel', 'glimpse',

  // Compact compounds
  'airnode', 'sunpulse', 'greenbit', 'ecobit',
  'leafnode', 'terravox', 'bioflux', 'earthpulse',

  // Invented / Brandable
  'quill', 'rune', 'clade', 'vane', 'shard',
  'glint', 'brisk', 'plume', 'sprig', 'thorn',
  'flint', 'slate', 'crest', 'vale',
];

// ── Generated 1-syllable combinations ───────────────────────────────────
function generateNames() {
  const prefixes = [
    's', 'fl', 'gr', 'br', 'cr', 'tr', 'pr', 'bl', 'cl', 'dr',
    'sp', 'st', 'sw', 'sh', 'th', 'gl', 'pl', 'fr', 'wr', 'sc',
    'sk', 'sn', 'sl', 'sm', 'qu', 'v', 'z', 'n', 'l', 'r',
    'm', 'w', 'k', 'j', 'h', 'f', 'b', 'd', 'g', 'p', 't'
  ];
  const cores = ['a', 'e', 'i', 'o', 'u', 'ai', 'ea', 'ee', 'oo', 'ou', 'oi', 'au', 'ie', 'ei'];
  const suffixes = [
    'x', 'n', 'l', 'r', 'm', 'th', 'se', 'ze', 'ke', 'ge',
    'de', 'te', 'pe', 'be', 'ft', 'nt', 'nd', 'nk', 'ng',
    'rk', 'rn', 'rd', 'rt', 'st', 'sk', 'sp', 'lt', 'lk',
    'lm', 'lp', 'mp', 'nch', 'rch', 'dge', 'tch'
  ];

  const generated = new Set();
  for (const p of prefixes) {
    for (const c of cores) {
      for (const s of suffixes) {
        const name = p + c + s;
        if (name.length >= 3 && name.length <= 6) {
          generated.add(name);
        }
      }
    }
  }
  return [...generated];
}

// ── Raw WHOIS lookup via TCP socket ─────────────────────────────────────
function whoisLookup(domain) {
  return new Promise((resolve, reject) => {
    const socket = new net.Socket();
    let data = '';

    socket.setTimeout(TIMEOUT);

    socket.connect(WHOIS_PORT, WHOIS_SERVER, () => {
      socket.write(domain + '\r\n');
    });

    socket.on('data', (chunk) => {
      data += chunk.toString();
    });

    socket.on('end', () => {
      resolve(data);
    });

    socket.on('timeout', () => {
      socket.destroy();
      reject(new Error('WHOIS timeout'));
    });

    socket.on('error', (err) => {
      reject(err);
    });
  });
}

// ── Check domain availability ───────────────────────────────────────────
async function checkDomain(name) {
  const domain = name + TLD;
  try {
    const raw = await whoisLookup(domain);

    // Verisign returns "No match for" when domain is available
    const available = raw.includes('No match for');

    if (available) {
      return { name, domain, available: true };
    }

    // Extract registrar from response
    const registrarMatch = raw.match(/Registrar:\s*(.+)/i);
    const expiryMatch = raw.match(/Registry Expiry Date:\s*(.+)/i);

    return {
      name,
      domain,
      available: false,
      registrar: registrarMatch ? registrarMatch[1].trim() : 'unknown',
      expiry: expiryMatch ? expiryMatch[1].trim() : null,
    };
  } catch (err) {
    return { name, domain, available: 'error', error: (err.message || '').slice(0, 80) };
  }
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ── Main ────────────────────────────────────────────────────────────────
async function main() {
  const args = process.argv.slice(2);
  let names = [];

  if (args.includes('--gen')) {
    const genIdx = args.indexOf('--gen');
    const count = parseInt(args[genIdx + 1]) || 100;
    console.log('Generating 1-syllable name candidates...');
    const generated = generateNames();
    console.log(`Generated ${generated.length} total. Sampling ${count} random for checking...`);
    const shuffled = generated.sort(() => Math.random() - 0.5);
    names = shuffled.slice(0, count);
  } else if (args.includes('--file')) {
    const fileIdx = args.indexOf('--file');
    const filePath = args[fileIdx + 1];
    if (!filePath) {
      console.error('Usage: node check-domains.mjs --file <path>');
      process.exit(1);
    }
    const content = fs.readFileSync(path.resolve(filePath), 'utf-8');
    names = content.split('\n').map(n => n.trim().toLowerCase()).filter(n => n && !n.startsWith('#'));
  } else if (args.length > 0) {
    names = args.map(n => n.trim().toLowerCase());
  } else {
    names = [...CURATED_NAMES];
  }

  // Deduplicate
  names = [...new Set(names)];

  console.log(`\n  Domain Availability Checker`);
  console.log(`  Checking ${names.length} names for ${TLD} availability`);
  console.log(`  WHOIS server: ${WHOIS_SERVER}`);
  console.log(`  Delay: ${DELAY_MS}ms between lookups\n`);
  console.log('─'.repeat(60));

  const available = [];
  const taken = [];
  const errors = [];

  for (let i = 0; i < names.length; i++) {
    const name = names[i];
    const progress = `[${String(i + 1).padStart(3)}/${names.length}]`;

    const result = await checkDomain(name);

    if (result.available === true) {
      console.log(`  ${progress}  ✓ AVAILABLE  ${result.domain}`);
      available.push(result);
    } else if (result.available === 'error') {
      console.log(`  ${progress}  ? ERROR      ${result.domain}  (${result.error})`);
      errors.push(result);
    } else {
      console.log(`  ${progress}    taken      ${result.domain}  (${result.registrar})`);
      taken.push(result);
    }

    // Rate limit between lookups
    if (i < names.length - 1) {
      await sleep(DELAY_MS);
    }
  }

  // ── Summary ─────────────────────────────────────────────────────────
  console.log('\n' + '='.repeat(60));
  console.log(`\n  RESULTS SUMMARY\n`);

  if (available.length > 0) {
    console.log(`  AVAILABLE DOMAINS (${available.length}):`);
    available.forEach(r => console.log(`    -> ${r.domain}`));
  } else {
    console.log('  No available domains found in this batch.');
  }

  if (errors.length > 0) {
    console.log(`\n  ERRORS (${errors.length}) - may need re-checking:`);
    errors.forEach(r => console.log(`    ?  ${r.domain}  (${r.error})`));
  }

  console.log(`\n  Taken: ${taken.length} | Available: ${available.length} | Errors: ${errors.length}`);
  console.log(`  Total checked: ${names.length}`);

  // Save results
  const resultsPath = path.join(__dirname, 'results.json');
  const results = {
    available: available.map(r => r.domain),
    taken: taken.map(r => ({ domain: r.domain, registrar: r.registrar })),
    errors: errors.map(r => ({ domain: r.domain, error: r.error })),
    checkedAt: new Date().toISOString(),
    totalChecked: names.length,
  };
  fs.writeFileSync(resultsPath, JSON.stringify(results, null, 2));
  console.log(`\n  Full results saved to: ${resultsPath}\n`);
}

main().catch(console.error);
