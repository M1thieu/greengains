# 🎯 Domain Finder CLI - Guide d'utilisation

## Installation rapide

```bash
cd tools
npm install
```

C'est tout! Aucune config supplémentaire (sauf API key pour l'AI).

## Démarrage

```bash
npm start
# ou
node cli/domain-finder.mjs
```

## 🤖 Mode AI (Recommandé)

### Setup une seule fois

Pour utiliser l'AI, set ton API key Anthropic:

**Windows (PowerShell):**
```powershell
$env:ANTHROPIC_API_KEY = "sk-ant-..."
```

**Mac/Linux:**
```bash
export ANTHROPIC_API_KEY="sk-ant-..."
```

**Permanent (ajout à .bashrc/.zshrc):**
```bash
echo 'export ANTHROPIC_API_KEY="sk-ant-..."' >> ~/.bashrc
```

### Utilisation

1. Lance l'app: `npm start`
2. Choisis **"🤖 Generate names with AI"**
3. Entre tes préférences:
   - **Concept:** "ambient sensors, passive monitoring"
   - **Style:** "abstract, 1-syllable, professional, not too explicit"
   - **Stratégie:** Greek letters, abstract words, phonetic variants, ou ALL
   - **Combien:** 50 noms (ou plus/moins)
   - **TLD:** .io, .com, .app, .dev
4. **BOOM!** L'AI génère des noms basés sur tes critères
5. L'app check automatiquement la disponibilité
6. Résultats sauvegardés dans `results-[timestamp].json`

### Exemple de session

```
🎯 Domain Finder AI
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

? What do you want to do? 🤖 Generate names with AI

🤖 AI-Powered Name Generation

? What concept/product? ambient sensors, passive air quality monitoring
? What style? abstract, 1-syllable, professional, tech startup vibe
? Name generation strategy? All strategies (mixed)
? How many names to generate? 50
? Which TLD to check? .io

✔ Generated 50 names in success

Generated names (preview):
siga, delz, lamz, myst, dryft, flux, sigmo, theyo, span, drift...

🔍 Checking 50 domains for .io availability...

[1/50] ✓ siga.io AVAILABLE
[2/50] ✗ delz.io taken
[3/50] ✓ lamora.io AVAILABLE
...

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 RESULTS SUMMARY

✓ Available: 5
✗ Taken: 43
? Errors: 2

🎉 AVAILABLE DOMAINS:

   ✓ siga.io
   ✓ lamora.io
   ✓ theyra.io
   ✓ fluxen.io
   ✓ skope.io

💾 Results saved to: results-1707598234567.json
```

## 📝 Mode Manuel (Sans AI)

Si tu veux pas utiliser l'API ou payer:

1. Choisis **"📝 Generate names manually"**
2. Même flow mais génération basée sur templates prédéfinis
3. Moins créatif mais gratuit et rapide

## ✅ Check des domaines spécifiques

Si t'as déjà des idées:

1. Choisis **"✅ Check specific domains"**
2. Entre tes noms séparés par virgules: `drift, pulse, sigma, lamz`
3. Choisis le TLD
4. Résultats instantanés

## 📄 Check depuis un fichier

Si t'as une grosse liste:

1. Crée un fichier `mynames.txt`:
   ```
   drift
   pulse
   sigma
   # commentaires avec #
   lamz
   flux
   ```
2. Choisis **"📄 Check from file"**
3. Entre le path: `mynames.txt`
4. GO!

## Stratégies de génération

### Greek Letters
Dérivés de lettres grecques avec sens scientifique:
- Delta (Δ) = change/variation → dela, delz, deltyx
- Sigma (Σ) = aggregation → siga, sigz, sigmyx
- Lambda (Λ) = light/wavelength → lama, lamz, lambyx

### Abstract Words
Mots abstraits évocateurs mais pas explicites:
- drift, mist, pulse, trace, gleam, span, flux

### Phonetic Variants
Twists orthographiques (style Lyft, Fiverr):
- flow → flo, floh
- sync → synq, synk
- glow → glo

### Ambient Concepts
Concepts liés aux capteurs ambiants:
- Mouvement: drift, shift, glide
- Observation: trace, peek, scope
- Nature: mist, haze, dew

## Tips

✨ **Pour un rebranding:**
1. Use AI mode avec "All strategies"
2. Génère 50-100 noms
3. Check .io ET .com (2 runs)
4. Compare les résultats

✨ **Pour trouver le nom parfait:**
- Sois spécifique dans le concept ET le style
- Test plusieurs stratégies
- Check multiple TLDs
- L'AI comprend le français aussi!

✨ **Partage avec ton équipe:**
- Envoie le dossier `tools/`
- Ils lancent `npm install` puis `npm start`
- Chacun peut run sa propre recherche

## Troubleshooting

**"ANTHROPIC_API_KEY not set"**
→ Set la variable d'environnement (voir section Setup)

**"No names generated"**
→ Essaye des critères moins restrictifs ou change de stratégie

**"WHOIS timeout"**
→ Normal pour 1-2 domaines sur 100, les WHOIS servers sont parfois lents

**"Cannot use import statement"**
→ Vérifie que `package.json` a `"type": "module"`

## Prochaine étape: Web App

Le code est déjà structuré pour ajouter une web app plus tard:
- `core/` = logique réutilisable
- `cli/` = interface CLI
- `web/` = future interface web (React + API)

Aucune réécriture nécessaire! 🚀
