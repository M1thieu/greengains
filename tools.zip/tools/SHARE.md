# Partager l'outil avec ton ami

## Fichiers à envoyer

Envoie ces 3 fichiers essentiels:

```
tools/
├── check-domains.mjs    (l'outil principal)
├── package.json         (config pour ESM)
└── README.md            (instructions d'utilisation)
```

**Optionnel:** Envoie aussi les fichiers de noms si tu veux qu'il teste les mêmes listes:
- `names-greek-derivatives.txt`
- `names-abstract-subtle.txt`
- `names-phonetic-variants.txt`
- etc.

## Méthodes de partage

### Option 1: ZIP
```bash
# Créer un ZIP avec les fichiers essentiels
cd tools
zip -r domain-checker.zip check-domains.mjs package.json README.md
```

Puis envoie `domain-checker.zip` à ton ami.

### Option 2: Git repo
Ton ami peut clone directement depuis ton repo et utiliser le dossier `tools/`:

```bash
git clone https://github.com/M1thieu/greengains.git
cd greengains/tools
node check-domains.mjs --help
```

### Option 3: Copier-coller manuel
Envoie les 3 fichiers par Slack/Discord/email, ton ami les met dans un dossier et c'est tout.

## Pour ton ami - Quick Start

1. Mettre les 3 fichiers dans un dossier
2. Ouvrir terminal dans ce dossier
3. Tester:
   ```bash
   node check-domains.mjs drift pulse sigma
   ```

Aucune installation nécessaire, juste Node.js!

## Créer ses propres listes

Ton ami peut créer un fichier texte avec ses idées:

```bash
# mynames.txt
drift
pulse
sigma
lambyx
vyb
```

Puis checker:
```bash
TLD=.com node check-domains.mjs --file mynames.txt
```
